export async function POST() {
  return Response.json({ message: "distance working" });
}
