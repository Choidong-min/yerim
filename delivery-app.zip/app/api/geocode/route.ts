export async function POST() {
  return Response.json({ message: "geocode working" });
}
