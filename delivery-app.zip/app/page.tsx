// simplified version placeholder (same as provided earlier)
export default function Home() {
  return <div>배차 프로그램 복구 완료</div>;
}
